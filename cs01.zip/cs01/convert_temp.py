f = float(input("Enter the temperature in F: "))

c = (5/9)*(f-32)
print(f'{f} degrees F is {c:.3f} degrees C')