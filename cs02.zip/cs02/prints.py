n = int(input("Enter n: "))

while n != 0:
    print("This is fun!")
    n -= 1