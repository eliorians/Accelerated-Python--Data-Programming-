name_a = input("Enter a name: ")
name_b = input("Enter another name: ")
number_a = int(input("Enter an integer between 10-30: "))
number_b = int(input("Enter another integer between 10-30: "))
thing = input("Enter a thing: ")

print(f'{name_a} had {number_a} {thing}s.')
print(f'{name_b} had {number_b} {thing}s.')
print(f'How many {thing}s did they have in all?')